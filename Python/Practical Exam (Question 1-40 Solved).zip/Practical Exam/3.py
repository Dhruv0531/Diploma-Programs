# WAP to find sum of first 10 natural nos.
sum = 0
for i in range(11):
    sum += i
print("Sum of first 10 Natural Numbers:", sum)
