# WAP to access methods of a user defined module
from user_module import add as a
print(a(10, 20))
