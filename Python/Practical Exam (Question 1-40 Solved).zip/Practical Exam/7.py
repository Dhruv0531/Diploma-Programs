# WAP using list comprehension to create a list of cubes of all nos upto 10.
cubes = [i**3 for i in range(11)]
print("List of Cubes of all numbers upto 10:", cubes)