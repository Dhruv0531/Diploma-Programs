# WAP illustrating the use of user defined package in Python.
from user_package.package import add as a
print(a(10, 20))
