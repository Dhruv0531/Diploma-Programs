#  WAP to create a list and demonstrate any four list methods.
# creating list
l1 = [5, 3, 1, 4, 2]
print("Initial List:", l1)
l1.pop()
print("List After Pop method:", l1)
l1.append(10)
print("List After Append Method", l1)
print("Max Element of List:", max(l1))
print("Min Element of List:", min(l1))
