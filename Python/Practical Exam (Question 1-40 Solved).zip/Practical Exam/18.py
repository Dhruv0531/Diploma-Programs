# WAP to demonstrate four built in string functions.
str = "hello world"
# converts first letter of sting to capital
print("Capatalize Function:", str.capitalize())
# converts first letter of each word to upper case
print("Title Function:", str.title())
print("Upper Function:", str.upper())  # converts string to upper case
print("Lower Function:", str.lower())  # converts string to lower case
