# WAP to access object methods
class Demo:
    def obj1(self):
        print("This is method 1")

    def obj2(self):
        print("This is method 2")

    def obj3(self):
        print("This is method 3")


d = Demo()
d.obj1()
d.obj2()
d.obj3()
