# WAP to create a tuple and demonstrate any four tuple methods/functions
t1 = (1, 2, 3, 4, 5)
print("Length of Tuple:", len(t1))
print("Sum of elements of tuple:", sum(t1))
print("Min Element of Tuple:", min(t1))
print("Max Element of Tuple:", max(t1))
# Method to convert tuple into list
l1 = list(t1)
print("Tuple converted to List:", l1)
