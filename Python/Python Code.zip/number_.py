# int
# flaot
# complex
x = 1
y = 1.0  # float
z = 1j  # complex
# type() - display the type of datatype
print(type(x))
print(type(y))
print(type(z))


# number conversion
#conversion to float
a = float(x)
print(a)

#conversion to int
b = int(y)
print(b)

#conversion to complex
c = complex(x)
print(c)

# operations on number
n = 10
m = 20
print(n)
print(m)

# math operations
# addition(+)
x = n+m
print(x)

# subtraction(-)
x = n-m
print(x)

# multiplication(*)
x = n*m
print(x)

# division(/)
x = n/m
print(x)

# modulus(%)
x = n % m
print(x)

#exponential(**)
x=n**m  # n raise to m
print(x)

#floor division(//) - dividing one number by another and then rounding the result to the closest integer that is smaller
x=n//m
print(x)
