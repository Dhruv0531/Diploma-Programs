import math
print("Enter a number:")
num = int(input())
sq = math.sqrt(num)
print(f"Square Root of {num} is {sq}")
