num1 = int(input("Enter first number:"))
num2 = int(input("Enter second number:"))

if num1 > num2:
    print(num1, "is Greater")
else:
    print(num2, "is Greater")
