
print("Even numbers from 1 to 100:")
num=1
while num<=100:
    if num%2==0:
        print(num,end=" ")
    num+=1