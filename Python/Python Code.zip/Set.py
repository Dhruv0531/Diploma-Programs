s={10,10,1.0,1.0,"Hello"}
print(s)