t = (10, 99.9, "Hello", 2+3j)
print(t)
print(type(t))