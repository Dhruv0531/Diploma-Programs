print("Enter 4 numbers:")
list=[]
for x in range(4):
    num=int(input())
    list.append(num)
print(f"Greatest Number:{max(list)}")
    