# Creating tuple
t = (10, 20, 30, 40, 50, [10, 20, 30])
# Accessing tuple
print("Initial Tuple:", t)
# Updating tuple
t[5][1] = "Hello"
print("Updated Tuple:", t)
# Deleting tuple
del t