#  Addition of 2 numbers
print("Enter first number:")
a = float(input())
print ("Enter second number:")
b = float(input())
c=a+b
print("Addition:",c) 