i = 1
while i <= 50:
    if i % 2 == 0:
        print(i)
    i = i +1
