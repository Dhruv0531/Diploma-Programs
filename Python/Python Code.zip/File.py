newfile = open("abc.txt",'w')
str=input("Enter text to write in file:")
print(str,file=newfile)
