# Strings
s = 'Hello,'  # String with single cout
s1 = "how are"  # String with diuble cout
s2 = '''you?'''  # String with triple cout
print(s, s1, s2)

# Printing string using seperator
str = "Happy"
str1 = "New Year"
str3 = 2024
print(str, str1, str3, sep=',')

# Printing string using string concatination (+) operator
a = 'Concat'
b = 'ination'
print(a+b)

# Printing string using end parameter
c='Here'
d='There'
print(c,end=" & ")
print(d)
