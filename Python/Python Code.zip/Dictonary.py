d = {1: 10, 2: 2.0, 3: "Hello"}
print(d)
d[3] = "Hi"
print(d)
