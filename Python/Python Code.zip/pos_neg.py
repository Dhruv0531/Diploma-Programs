print("Enter a number:")
num=int(input())
if num>0:
    print("Number is Positive")
elif num == 0:
    print("Number is Zero")
else:
    print("Number is Negative")