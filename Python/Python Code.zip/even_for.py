for num in range (1,101):
    if num%2==0:print(num)