print("Enter two numbers:")
n1 = int(input())
n2 = int(input())
print(f"Values before Swaping: A={n1}, B={n2}")
n1, n2 = n2, n1
print(f"Values After Swaping: A={n1}, B={n2}")