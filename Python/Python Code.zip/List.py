l = [10, 99.9, "Hello", 2+3j]
print(l)
l[3] = '''Hi'''
print(l)
